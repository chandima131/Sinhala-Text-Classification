# Sinhala Stopword list

This list was produced by the following research:

Lakmal, D., Ranathunga, S., Peramuna, S., & Herath, I. (2020, May). Word Embedding Evaluation for Sinhala. In Proceedings of The 12th Language Resources and Evaluation Conference (pp. 1874-1881).
Refer to https://github.com/nlpcuom/Sinhala-Stopword-list for more details.

